create function change_workers_update() returns trigger
    language plpgsql
as
$$
DECLARE cur CURSOR FOR SELECT salary,work_time FROM workers;
 work_lvl_id int;

	
  BEGIN
  
    IF (TG_OP = 'UPDATE') THEN
	work_lvl_id = 2;
  INSERT INTO workers_access 
  (workers_access_level)
  VALUES 
  (work_lvl_id);
  
   RETURN NEW;
   END IF;
 


	END; $$;

alter function change_workers_update() owner to postgres;

