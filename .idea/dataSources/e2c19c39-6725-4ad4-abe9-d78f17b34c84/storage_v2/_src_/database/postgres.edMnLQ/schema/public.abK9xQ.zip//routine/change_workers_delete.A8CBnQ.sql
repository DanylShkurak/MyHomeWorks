create function change_workers_delete() returns trigger
    language plpgsql
as
$$
	DECLARE curs CURSOR FOR SELECT salary,work_time FROM workers;
	storage_variable record;
	counter int;


    BEGIN
  	OPEN curs;
  	LOOP
    IF (TG_OP = 'DELETE') THEN
     FETCH curs INTO storage_variable;
     EXIT WHEN NOT FOUND;
      SELECT COUNT(*) INTO counter FROM workers;
  	UPDATE workers SET
  	salary = storage_variable.salary + (storage_variable.salary/counter) ,
      work_time = storage_variable.work_time + (storage_variable.work_time/counter);
     RETURN OLD;
     END IF;
  	END LOOP;
  	close curs;
  	END;  $$;

alter function change_workers_delete() owner to postgres;

